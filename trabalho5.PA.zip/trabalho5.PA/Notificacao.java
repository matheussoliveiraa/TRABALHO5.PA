package org.example;


public interface Notificacao {
    void enviar(String mensagem);
}
